{{View::make('frontend.layouts.header')}}
@yield("content")
{{View::make('frontend.layouts.footer')}}