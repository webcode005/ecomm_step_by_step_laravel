@extends("frontend.layouts.master")
@section("content")
<link rel="stylesheet" href="{{asset('frontend/css/checkout.css')}}">

    <section class="inner-section single-banner" style="background: url({{asset('frontend/images/single-banner.jpg')}}) no-repeat center;">
        <div class="container">
            <h2>cart</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item"><a href="shop-4column.html">shop grid</a></li>
                <li class="breadcrumb-item active" aria-current="page">cart</li>
            </ol>
        </div>
    </section>
    <section class="inner-section checkout-part">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="alert-info">
                        <p>Returning customer? <a href="/login">Click here to login</a></p>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="account-card">
                        <div class="account-title">
                            <h4>Your order</h4>
                        </div>
                        <div class="account-content">
                            <div class="table-scroll">
                                <table class="table-list">
                                    <thead>
                                        <tr>
                                            <th scope="col">Serial</th>
                                            <th scope="col">Product</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Price</th>
                                            <th scope="col">brand</th>
                                            <th scope="col">quantity</th>
                                            <th scope="col">action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        print_r($orders);
                                         $ik='1'; ?>
                                      @foreach ($orders as $item)
                                          
                                      
                                        <tr>
                                            <td class="table-serial">
                                                <h6>{{$ik++;}}</h6>
                                            </td>
                                            <td class="table-image"><img src="{{asset('frontend/images/product/'.$item->image)}}" alt="product"></td>
                                            <td class="table-name">
                                                <h6>{{$item->name}}</h6>
                                            </td>
                                            <td class="table-price">
                                                <h6>${{$item->price}}<small>/kilo</small></h6>
                                            </td>
                                            <td class="table-brand">
                                                <h6>{{$item->description}}</h6>
                                            </td>
                                            <td class="table-quantity">
                                                <h6>s</h6>
                                            </td>
                                            
                                        </tr>
                                        @endforeach 
                                    </tbody>
                                </table>
                            </div>

<a href="/ordernow" class="btn btn-success">Order Now</a>

                            <div class="chekout-coupon"><button class="coupon-btn">Do you have a coupon code?</button>
                                <form class="coupon-form"><input type="text"
                                        placeholder="Enter your coupon code"><button
                                        type="submit"><span>apply</span></button></form>
                            </div>
                            <div class="checkout-charge">
                               
                                <ul>
                                    <li><span>Sub total</span><span>$25</span></li>
                                    <li><span>delivery fee</span><span>$10.00</span></li>
                                    <li><span>discount</span><span>$00.00</span></li>
                                    <li><span>Total<small>(Incl. VAT)</small></span><span>$277.00</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
    </section>
    <div class="modal fade" id="contact-add">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                        class="icofont-close"></i></button>
                <form class="modal-form">
                    <div class="form-title">
                        <h3>add new contact</h3>
                    </div>
                    <div class="form-group"><label class="form-label">title</label><select class="form-select">
                            <option selected>choose title</option>
                            <option value="primary">primary</option>
                            <option value="secondary">secondary</option>
                        </select></div>
                    <div class="form-group"><label class="form-label">number</label><input class="form-control"
                            type="text" placeholder="Enter your number"></div><button class="form-btn"
                        type="submit">save contact info</button>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="address-add">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                        class="icofont-close"></i></button>
                <form class="modal-form">
                    <div class="form-title">
                        <h3>add new address</h3>
                    </div>
                    <div class="form-group"><label class="form-label">title</label><select class="form-select">
                            <option selected>choose title</option>
                            <option value="home">home</option>
                            <option value="office">office</option>
                            <option value="Bussiness">Bussiness</option>
                            <option value="academy">academy</option>
                            <option value="others">others</option>
                        </select></div>
                    <div class="form-group"><label class="form-label">address</label><textarea class="form-control"
                            placeholder="Enter your address"></textarea></div><button class="form-btn"
                        type="submit">save address info</button>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="payment-add">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                        class="icofont-close"></i></button>
                <form class="modal-form">
                    <div class="form-title">
                        <h3>add new payment</h3>
                    </div>
                    <div class="form-group"><label class="form-label">card number</label><input class="form-control"
                            type="text" placeholder="Enter your card number"></div><button class="form-btn"
                        type="submit">save card info</button>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="contact-edit">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                        class="icofont-close"></i></button>
                <form class="modal-form">
                    <div class="form-title">
                        <h3>edit contact info</h3>
                    </div>
                    <div class="form-group"><label class="form-label">title</label><select class="form-select">
                            <option value="primary" selected>primary</option>
                            <option value="secondary">secondary</option>
                        </select></div>
                    <div class="form-group"><label class="form-label">number</label><input class="form-control"
                            type="text" value="+8801838288389"></div><button class="form-btn" type="submit">save contact
                        info</button>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="address-edit">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content"><button class="modal-close" data-bs-dismiss="modal"><i
                        class="icofont-close"></i></button>
                <form class="modal-form">
                    <div class="form-title">
                        <h3>edit address info</h3>
                    </div>
                    <div class="form-group"><label class="form-label">title</label><select class="form-select">
                            <option value="home" selected>home</option>
                            <option value="office">office</option>
                            <option value="Bussiness">Bussiness</option>
                            <option value="academy">academy</option>
                            <option value="others">others</option>
                        </select></div>
                    <div class="form-group"><label class="form-label">address</label><textarea class="form-control"
                            placeholder="jalkuri, fatullah, narayanganj-1420. word no-09, road no-17/A"></textarea>
                    </div><button class="form-btn" type="submit">save address info</button>
                </form>
            </div>
        </div>
    </div>
    <section class="news-part" style="background: url(images/newsletter.jpg) no-repeat center;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-5 col-lg-6 col-xl-7">
                    <div class="news-text">
                        <h2>Get 20% Discount for Subscriber</h2>
                        <p>Lorem ipsum dolor consectetur adipisicing accusantium</p>
                    </div>
                </div>
                <div class="col-md-7 col-lg-6 col-xl-5">
                    <form class="news-form"><input type="text" placeholder="Enter Your Email Address"><button><span><i
                                    class="icofont-ui-email"></i>Subscribe</span></button></form>
                </div>
            </div>
        </div>
    </section>
    <section class="intro-part">
        <div class="container">
            <div class="row intro-content">
                <div class="col-sm-6 col-lg-3">
                    <div class="intro-wrap">
                        <div class="intro-icon"><i class="fas fa-truck"></i></div>
                        <div class="intro-content">
                            <h5>free home delivery</h5>
                            <p>Lorem ipsum dolor sit amet adipisicing elit nobis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="intro-wrap">
                        <div class="intro-icon"><i class="fas fa-sync-alt"></i></div>
                        <div class="intro-content">
                            <h5>instant return policy</h5>
                            <p>Lorem ipsum dolor sit amet adipisicing elit nobis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="intro-wrap">
                        <div class="intro-icon"><i class="fas fa-headset"></i></div>
                        <div class="intro-content">
                            <h5>quick support system</h5>
                            <p>Lorem ipsum dolor sit amet adipisicing elit nobis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="intro-wrap">
                        <div class="intro-icon"><i class="fas fa-lock"></i></div>
                        <div class="intro-content">
                            <h5>secure payment way</h5>
                            <p>Lorem ipsum dolor sit amet adipisicing elit nobis.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 

@endsection