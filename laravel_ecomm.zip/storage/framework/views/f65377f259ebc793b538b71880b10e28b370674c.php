<?php echo e(View::make('frontend.layouts.header')); ?>

<?php echo $__env->yieldContent("content"); ?>
<?php echo e(View::make('frontend.layouts.footer')); ?><?php /**PATH F:\xampp\htdocs\ecomm_by_step_by_step\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>