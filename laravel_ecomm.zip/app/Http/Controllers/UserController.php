<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use App\Models\User;


class UserController extends Controller
{
    //
    public function login(Request $req)
    {
        # code...

        //return $req->input();

        //return $users = User::all();


         $user = User::where(['email'=>$req->useremail])->first();

            if (!$user || hash::check($req->userpass,$user->password)) {
                # code...

                return "Username Or Password not matched";

            } else {
                # code...
                $req->session()->put('user',$user);
                return redirect('/home');
            }
            



    }
    public function register(Request $req)
    {
        # code...

        echo"Register";

        //return $req->input();
    }
}
