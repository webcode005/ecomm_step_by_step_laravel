<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Product;
use App\Models\Cart;
use App\Models\Order;
use Session;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    function index()
    {
        $data = Product::all();

        return view('frontend.index',['products'=>$data]);
    }

    function detail($id)
    {
       
        $data = Product::find($id);

        return view('frontend.detail',['product'=>$data]);
    }

    function search(Request $req)
    {
      
        $data = Product::where('name','like','%'.$req->input('query').'%')->get();

        return view('frontend.search',['products'=>$data]);
    }

    function addToCart(Request $req)
    {
        if ($req->session()->has('user')) {
            $cart = new Cart;
            $cart -> user_id = $req->session()->get('user')['id'] ;
            $cart -> product_id = $req->product_id ;
            $cart ->save();

            return redirect('/home2');


        } else {
           return redirect('/login');
        }
        
    }

    static function CartItem()
    {
        $userId=Session::get('user')['id'] ;
        return Cart::where('user_id',$userId)->count();
    }

    function cartList(Request $req)
    {
        $userId = Session::get('user')['id'];

            $products= DB::table('carts')
            ->join('products','carts.product_id','=','products.id')
            ->where('carts.user_id',$userId)
            ->select('products.*','carts.id as cart_id')
            ->get();

            return view('frontend.cart',['products'=>$products]);

    }

    function removeCart($id)
    {
        Cart::destroy($id);

         return redirect('/cart');
    }
    
    function ordernow(Request $req)
    {
        $userId = Session::get('user')['id'];

            $totals= DB::table('carts')
            ->join('products','carts.product_id','=','products.id')
            ->where('carts.user_id',$userId)
            ->sum('products.price');
            return view('frontend.order',['total'=>$totals]);

    }

    function orderplace(Request $req)
    {
        //return $req->input();

        $userId = Session::get('user')['id'];

         $allCart = Cart::where('user_id',$userId)->get();

        //  print_r($allCart); die();
        foreach ($allCart as $cart) {
            
            $order= new Order;
            $order->product_id=$cart['product_id'];
            $order->user_id=$cart['user_id'];
            $order->status="Pending";
            $order->payment_method=$req->payment;
            $order->payment_status="Pending";
            $order->address=$req->address;
            $order->save();

            Cart::where('user_id',$userId)->delete();

        }

         $req->input();

         return redirect('/');

    }

    function order(Request $req)
    {
        $userId = Session::get('user')['id'];

         $orders= DB::table('orders')
        ->join('products','orders.product_id','=','products.id')
        ->where('orders.user_id',$userId)
        ->select('products.*')
        ->get();

        return view('frontend.orderlist',['orders'=>$orders]);

    }
    
}
