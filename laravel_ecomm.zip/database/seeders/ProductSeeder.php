<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('products')->insert([
            [
            'name'=> 'Fresh Organic Green Chilis',
            'price'=> 28,
            'description'=> 'Lorem ipsum dolor sit amet consectetur adipisicing elit facere harum natus amet soluta fuga consectetur alias veritatis quisquam ab eligendi itaque eos maiores quibusdam.',
            'image'=> '01.jpg',
            'quantity'=> 10,

            ],
            [
                'name'=> 'Fresh Green Chilis',
                'price'=> 28,
                'description'=> 'Lorem ipsum dolor sit amet consectetur adipisicing elit facere harum natus amet soluta fuga consectetur alias veritatis quisquam ab eligendi itaque eos maiores quibusdam.',
                'image'=> '01.jpg',
                'quantity'=> 10,

            ],
            [
                'name'=> 'Fresh Bringle Chlis',
                'price'=> 48,
                'description'=> 'Lorem ipsum dolor sit amet consectetur adipisicing elit facere harum natus amet soluta fuga consectetur alias veritatis quisquam ab eligendi itaque eos maiores quibusdam.',
                'image'=> '04.jpg',
                'quantity'=> 10,

            ],
            [
                'name'=> 'Fresh Lady Finger ',
                'price'=> 18,
                'description'=> 'Lorem ipsum dolor sit amet consectetur adipisicing elit facere harum natus amet soluta fuga consectetur alias veritatis quisquam ab eligendi itaque eos maiores quibusdam.',
                'image'=> '05.jpg',
                'quantity'=> 10,

            ],
            [
                'name'=> 'Fresh Green Chilis',
                'price'=> 28,
                'description'=> 'Lorem ipsum dolor sit amet consectetur adipisicing elit facere harum natus amet soluta fuga consectetur alias veritatis quisquam ab eligendi itaque eos maiores quibusdam.',
                'image'=> '01.jpg',
                'quantity'=> 10,

            ],

        ]);


    }
}
